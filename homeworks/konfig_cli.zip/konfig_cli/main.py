import cmd
import sys
import os
import zipfile
import configparser
import io

class MyCLI(cmd.Cmd):
    config = configparser.ConfigParser()
    config.read("config.ini")
    print(config['usr'])
    prompt = '>> '  # Change the prompt text
    intro = 'Welcome to CLI by Boyko Danimir'

    def __init__(self, zip_path):
        super().__init__()
        self.zip_path = zip_path
        self.current_directory = ''  # Start at the root of the zip
        try:
            self.zip_file = zipfile.ZipFile(self.zip_path, 'r')
        except FileNotFoundError:
            print(f"Error: File '{self.zip_path}' not found.")
            sys.exit(1)

    def do_ls(self, line):
        """List files and directories in the current directory."""
        path = self.current_directory or ''  # Root if empty
        path_length = len(path)
        contents = set()
        for name in self.zip_file.namelist():
            if name.startswith(path) and name != path:
                remaining_path = name[path_length:]
                first_part = remaining_path.split('/', 1)[0]
                contents.add(first_part)
        for item in sorted(contents):
            print(item)
    def do_cd(self, directory):
        """Change the current directory."""
        new_dir = os.path.join(self.current_directory, directory).rstrip('/') + '/'
        if any(name.startswith(new_dir) for name in self.zip_file.namelist()):
            self.current_directory = new_dir
            print(f"Current directory changed to {self.current_directory}")
        else:
            print(f"Directory '{directory}' does not exist.")

    def do_cat(self, filename):
        """Read the contents of a file inside the zip."""
        file_path = os.path.join(self.current_directory, filename)
        try:
            with self.zip_file.open(file_path) as file:
                print(file.read().decode())
        except KeyError:
            print(f"File '{filename}' not found.")
        except Exception as e:
            print(f"Error: {e}")

    def do_pwd(self, line):
        """Print the current directory in the virtual file system."""
        print(f"Current directory: {self.current_directory or '/'}")

    def do_quit(self, line):
        """Exit the CLI."""
        print("Exiting...")
        return True

    def postcmd(self, stop, line):
        print()
        return stop

    def do_rmdir(self, directory):
        """Remove an empty directory inside the zip."""
        dir_path = os.path.join(self.current_directory, directory).rstrip('/') + '/'

        sub_items = [name for name in self.zip_file.namelist() if name.startswith(dir_path)]

        if len(sub_items) == 0:
            print(f"Directory '{directory}' does not exist.")
        elif len(sub_items) == 1 and sub_items[0] == dir_path:  # Директория существует и пуста
            temp_zip = io.BytesIO()  # Создаем новый буфер в памяти
            with zipfile.ZipFile(temp_zip, 'w') as zip_write:
                for item in self.zip_file.infolist():
                    if not item.filename.startswith(dir_path):
                        zip_write.writestr(item, self.zip_file.read(item.filename))

            temp_zip.seek(0)
            self.zip_file = zipfile.ZipFile(temp_zip, 'r')
            print(f"Directory '{directory}' removed.")
        else:
            print(f"Directory '{directory}' is not empty or does not exist.")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python main.py <virtual_fs.zip>")
        sys.exit(1)
    zip_path = sys.argv[1]
    MyCLI(zip_path).cmdloop()
