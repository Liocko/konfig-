import unittest
import zipfile
import io
from main import MyCLI
from unittest.mock import patch

class TestMyCLI(unittest.TestCase):

    def setUp(self):
        self.zip_buffer = io.BytesIO()
        with zipfile.ZipFile(self.zip_buffer, 'w') as test_zip:
            test_zip.writestr('file1.txt', 'Content of file1')
            test_zip.writestr('dir1/file2.txt', 'Content of file2 in dir1')
            test_zip.writestr('dir2/', '')  # Пустая папка
        self.zip_buffer.seek(0)  # Перемещаем указатель в начало

        self.cli = MyCLI(self.zip_buffer)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_rmdir_empty_dir(self, mock_stdout):
        """Test 'rmdir' command to remove an empty directory."""
        self.cli.do_rmdir('dir2')
        output = mock_stdout.getvalue()
        self.assertIn("Directory 'dir2' removed.", output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_rmdir_non_empty_dir(self, mock_stdout):
        """Test 'rmdir' command on a non-empty directory."""
        self.cli.do_rmdir('dir1')
        output = mock_stdout.getvalue()
        self.assertIn("Directory 'dir1' is not empty or does not exist.", output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_rmdir_non_existent_dir(self, mock_stdout):
        """Test 'rmdir' command on a non-existent directory."""
        self.cli.do_rmdir('dir3')
        output = mock_stdout.getvalue()
        self.assertIn("Directory 'dir3' does not exist.", output)
    @patch('sys.stdout', new_callable=io.StringIO)
    def test_ls_root(self, mock_stdout):
        """Test 'ls' command in the root of the zip."""
        self.cli.do_ls('')
        output = mock_stdout.getvalue()
        self.assertIn('file1.txt', output)
        self.assertIn('dir1', output)
        self.assertIn('dir2', output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_cd_dir(self, mock_stdout):
        """Test 'cd' command to change directory."""
        self.cli.do_cd('dir1')
        self.assertEqual(self.cli.current_directory, 'dir1/')
        self.cli.do_ls('')
        output = mock_stdout.getvalue()
        self.assertIn('file2.txt', output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_cd_invalid_dir(self, mock_stdout):
        """Test 'cd' command with an invalid directory."""
        self.cli.do_cd('nonexistent')
        output = mock_stdout.getvalue()
        self.assertIn("Directory 'nonexistent' does not exist.", output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_cat_file(self, mock_stdout):
        """Test 'cat' command to read file contents."""
        self.cli.do_cat('file1.txt')
        output = mock_stdout.getvalue()
        self.assertIn('Content of file1', output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_cat_invalid_file(self, mock_stdout):
        """Test 'cat' command with a non-existent file."""
        self.cli.do_cat('nonexistent.txt')
        output = mock_stdout.getvalue()
        self.assertIn("File 'nonexistent.txt' not found.", output)

    @patch('sys.stdout', new_callable=io.StringIO)
    def test_pwd(self, mock_stdout):
        """Test 'pwd' command."""
        self.cli.do_pwd('')
        output = mock_stdout.getvalue()
        self.assertIn('Current directory: /', output)

    def test_quit(self):
        """Test 'quit' command."""
        result = self.cli.do_quit('')
        self.assertTrue(result)

if __name__ == '__main__':
    unittest.main()
